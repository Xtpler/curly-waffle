# Roadmap

- [x] Add the stadium LED image/video billboard carousel.
- [x] Prevent missing account data from crashing the accounts market and add loading skeletons.
- [x] Add the unban and account recovery tab with validated upload and safe submission.
- [x] Fix mobile top spacing and apply the requested dark turquoise color system.
- [x] Verify type safety and preview build health.
- [x] Keep the admin dashboard link visible immediately for the master administrator.
- [x] Make account-market fetch failures silent and show a stable empty state.
- [x] Prevent the profile and support headings from being covered by the header.
- [x] Restrict admin navigation visibility to master, admin, and super admin accounts.
- [x] Protect direct access to `/admin` with an automatic redirect for normal users.