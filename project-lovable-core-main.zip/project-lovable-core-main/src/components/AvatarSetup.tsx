import { useEffect, useRef, useState } from 'react';
import { Camera, Check, ImagePlus, Loader2, SwitchCamera, X } from 'lucide-react';
import { toast } from 'sonner';
import { Logo } from '@/components/Logo';
import { useAuth } from '@/context/AuthContext';
import { uploadAvatar } from '@/lib/data';
import { supabase } from '@/lib/supabase';

export const AVATAR_SKIP_KEY = 'apm-avatar-skip';
const DEFAULT_AVATAR = '/placeholder-user.jpg';

export function AvatarSetup() {
  const { profile, refreshProfile } = useAuth();
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState('');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facing, setFacing] = useState<'user' | 'environment'>('user');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const pendingFile = useRef<File | null>(null);

  useEffect(() => {
    if (videoRef.current && stream) videoRef.current.srcObject = stream;
  }, [stream]);

  const stopCamera = () => {
    stream?.getTracks().forEach((t) => t.stop());
    setStream(null);
    setCameraOpen(false);
  };

  const startCamera = async (mode: 'user' | 'environment' = facing) => {
    stopCamera();
    try {
      const next = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode, width: { ideal: 720 }, height: { ideal: 720 } },
        audio: false,
      });
      setFacing(mode);
      setStream(next);
      setCameraOpen(true);
      requestAnimationFrame(() => {
        if (videoRef.current) videoRef.current.srcObject = next;
      });
    } catch {
      toast.error('تعذّر فتح الكاميرا. يمكنك اختيار صورة من المعرض.');
    }
  };

  const captureFrame = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width = video.videoWidth || 480;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        const file = new File([blob], `avatar-${Date.now()}.jpg`, { type: 'image/jpeg' });
        pendingFile.current = file;
        setPreview(URL.createObjectURL(blob));
        stopCamera();
      },
      'image/jpeg',
      0.9,
    );
  };

  const pickFile = (file: File | undefined) => {
    if (!file) return;
    pendingFile.current = file;
    setPreview(URL.createObjectURL(file));
  };

  const finish = () => {
    try {
      window.localStorage.setItem(AVATAR_SKIP_KEY, '1');
      window.localStorage.setItem('apm-view', 'home');
    } catch {
      /* private mode */
    }
    window.location.replace('/');
  };

  const skip = () => finish();

  const save = async () => {
    if (!profile || !pendingFile.current) {
      toast.error('اختر صورة أولاً من الكاميرا أو المعرض');
      return;
    }
    setBusy(true);
    let stored = DEFAULT_AVATAR;
    try {
      stored = await uploadAvatar(profile.id, pendingFile.current);
    } catch {
      toast.message('تعذّر رفع الصورة الآن، تم استخدام صورة مؤقتة ويمكنك تغييرها لاحقاً');
    }
    try {
      const { error } = await supabase.from('profiles').update({ avatar_url: stored }).eq('id', profile.id);
      if (error) throw error;
      await refreshProfile();
      finish();
    } catch {
      toast.error('تعذّر حفظ صورة الحساب، يمكنك تخطي هذه الخطوة والمتابعة');
    }
    setBusy(false);
  };


  return (
    <div className="min-h-screen overflow-hidden bg-slate-950" dir="rtl">
      <div className="auth-noise" />
      <div className="relative mx-auto flex min-h-screen max-w-lg flex-col items-center justify-center px-5 py-10">
        <Logo />
        <h1 className="mt-8 text-center text-2xl font-bold text-white">أكمل إعداد حسابك</h1>
        <p className="mt-3 text-center text-sm leading-7 text-slate-400">
          صورة الملف الشخصي إلزامية قبل الدخول إلى لوحة Ali Pro Media. التقط صورة مباشرة أو اختر من المعرض.
        </p>

        <div className="mt-8 flex h-40 w-40 items-center justify-center overflow-hidden rounded-full border-2 border-emerald-400/40 bg-white/[.04] shadow-[0_0_40px_rgba(16,185,129,.2)]">
          {preview ? (
            <img src={preview} alt="معاينة الصورة" className="h-full w-full object-cover" />
          ) : (
            <Camera className="text-emerald-400" size={42} />
          )}
        </div>

        <div className="mt-8 grid w-full grid-cols-2 gap-3">
          <button
            onClick={() => startCamera('user')}
            className="flex items-center justify-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 py-3.5 text-sm font-bold text-emerald-200"
          >
            <Camera size={18} /> التقاط مباشر
          </button>
          <button
            onClick={() => fileRef.current?.click()}
            className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[.05] py-3.5 text-sm font-bold text-white"
          >
            <ImagePlus size={18} /> من المعرض
          </button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          hidden
          onChange={(e) => pickFile(e.target.files?.[0])}
        />

        <button
          onClick={save}
          disabled={busy || !preview}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 py-3.5 text-sm font-bold text-slate-950 disabled:opacity-40"
        >
          {busy ? <Loader2 className="animate-spin" size={18} /> : <Check size={18} />}
          تأكيد والمتابعة
        </button>

        <button
          onClick={skip}
          disabled={busy}
          className="mt-4 text-xs font-medium text-slate-400 underline underline-offset-4 disabled:opacity-40"
        >
          تخطي هذه الخطوة لاحقاً
        </button>
      </div>

      {cameraOpen && (
        <div className="fixed inset-0 z-[130] flex flex-col bg-slate-950">
          <div className="flex items-center justify-between px-4 py-4">
            <button onClick={stopCamera} className="rounded-xl bg-white/10 p-2 text-white">
              <X />
            </button>
            <p className="text-sm font-bold text-white">التقاط صورة الحساب</p>
            <button
              onClick={() => startCamera(facing === 'user' ? 'environment' : 'user')}
              className="rounded-xl bg-white/10 p-2 text-white"
            >
              <SwitchCamera />
            </button>
          </div>
          <video ref={videoRef} autoPlay playsInline muted className="min-h-0 flex-1 bg-black object-cover" />
          <div className="p-6">
            <button
              onClick={captureFrame}
              className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border-4 border-white bg-emerald-400"
            />
          </div>
          <canvas ref={canvasRef} className="hidden" />
        </div>
      )}
    </div>
  );
}
