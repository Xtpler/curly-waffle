import { ArrowLeft } from 'lucide-react';

const HIGHLIGHTS = [
  ['حساب يحتاج نمو؟', 'نوفر لك الأدوات والخدمات المناسبة.'],
  ['تريد حضور أقوى؟', 'حلول للسوشيال ميديا بمكان واحد.'],
  ['تبحث عن السرعة والتوفير؟', 'خيارات متعددة حسب احتياجك.'],
] as const;

export function HeroBanner({ onCta }: { banners?: unknown[]; onCta?: () => void }) {
  return (
    <section dir="rtl" className="mx-auto max-w-[1440px] px-4 pt-6 sm:px-6 lg:px-10">
      <div className="hero-minimal relative overflow-hidden rounded-[32px] border border-emerald-500/20 bg-[#050505] px-6 py-12 sm:px-10 sm:py-16 lg:px-16 lg:py-20">
        <div className="hero-neon-orb" aria-hidden />
        <div className="hero-grid-minimal" aria-hidden />
        <div className="relative z-10 max-w-4xl">
          <p className="mb-5 inline-flex rounded-full border border-emerald-500/20 bg-emerald-400/10 px-3 py-1 text-xs font-bold text-[#00e599]">منصة رقمية أبسط وأسرع</p>
          <h1 className="font-display text-4xl font-extrabold leading-[1.2] tracking-tight text-white sm:text-6xl lg:text-7xl"><span className="hero-neon-text">مو مجرد</span> خدمات رقمية.</h1>
          <p className="mt-5 text-xl font-bold text-white/80 sm:text-2xl lg:text-3xl">نحن نسهّل عليك <span className="text-[#00e599]">الطرِيق</span>.</p>
          <div className="mt-10 grid gap-3 md:grid-cols-3">
            {HIGHLIGHTS.map(([title, body]) => <div key={title} className="rounded-2xl border border-emerald-500/20 bg-[#0d0d10] p-5 shadow-[0_0_30px_rgba(0,229,153,.05)]"><p className="font-bold text-white">{title}</p><p className="mt-2 text-sm leading-7 text-slate-300">{body}</p></div>)}
          </div>
          <button onClick={onCta} className="mt-8 inline-flex items-center gap-2 rounded-xl bg-[#00e599] px-6 py-3.5 text-sm font-extrabold text-[#04120d] shadow-[0_14px_45px_rgba(0,229,153,.25)] hover:-translate-y-0.5 hover:bg-[#17f3aa]">ابدأ الآن <ArrowLeft size={17} /></button>
          <div className="hero-road mt-10" aria-hidden><svg viewBox="0 0 1000 170" preserveAspectRatio="none" className="h-28 w-full overflow-visible"><path d="M-20 145 C150 20 260 165 410 100 S670 20 1020 145" fill="none" stroke="#00e599" strokeWidth="4" strokeLinecap="round" /><path d="M-20 145 C150 20 260 165 410 100 S670 20 1020 145" fill="none" stroke="#00e599" strokeWidth="12" strokeLinecap="round" opacity=".22" /></svg></div>
        </div>
      </div>
    </section>
  );
}
