import { useRef, useState } from 'react';
import { FileUp, Loader2, X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { uploadAttachment } from '@/lib/store';

export function UnbanAppealModal({ open, onClose, userId, onDone }: { open: boolean; onClose: () => void; userId: string; onDone?: () => void }) {
  const [reason, setReason] = useState('');
  const [phone, setPhone] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  if (!open) return null;

  const submit = async () => {
    if (!reason.trim() || !phone.trim()) { toast.error('أدخل سبب الاعتراض ورقم الهاتف أو واتساب'); return; }
    setBusy(true);
    try {
      // المرفق اختياري: عند فشل الرفع يُسجَّل الطلب مع رابط فارغ
      let attachment_url = '';
      try { attachment_url = await uploadAttachment(userId, file); } catch { attachment_url = ''; }
      const base = { user_id: userId, reason: reason.trim(), contact_phone: phone.trim(), attachment_url };
      let { error } = await (supabase.from as (t: string) => any)('unban_appeals').insert({ ...base, proof_image_url: attachment_url });
      if (error) ({ error } = await (supabase.from as (t: string) => any)('unban_appeals').insert(base));
      if (error) throw error;
      toast.success('تم تقديم الطلب بنجاح');
      setReason(''); setPhone(''); setFile(null); onDone?.(); onClose();
    } catch { toast.error('تعذر إرسال الطلب، يرجى المحاولة مرة أخرى'); }
    finally { setBusy(false); }
  };

  return <div className="fixed inset-0 z-[220] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm" dir="rtl">
    <div className="w-full max-w-lg rounded-3xl border border-emerald-500/20 bg-[#0d0d10] p-6 shadow-2xl">
      <div className="flex items-center justify-between"><div><h2 className="text-lg font-bold text-white">قسم فتح الباند</h2><p className="mt-1 text-xs text-slate-400">أرسل اعتراضك وسيراجعه فريق الإدارة.</p></div><button onClick={onClose} className="text-slate-400 hover:text-white"><X /></button></div>
      <div className="mt-6 space-y-4">
        <textarea value={reason} onChange={e=>setReason(e.target.value)} placeholder="سبب الاعتراض" className="min-h-28 w-full rounded-xl border border-white/10 bg-white/[.04] p-3 text-sm text-white outline-none placeholder:text-slate-500" />
        <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="رقم الهاتف / واتساب" dir="ltr" className="h-12 w-full rounded-xl border border-white/10 bg-white/[.04] px-3 text-sm text-white outline-none placeholder:text-slate-500" />
        <input ref={ref} type="file" accept="image/*,.pdf" hidden onChange={e=>setFile(e.target.files?.[0] ?? null)} />
        <button onClick={()=>ref.current?.click()} className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-emerald-500/30 bg-emerald-400/5 px-4 py-4 text-xs font-bold text-emerald-300"><FileUp size={17}/>{file ? file.name : 'إرفاق مستند أو صورة (اختياري)'}</button>
        <button disabled={busy} onClick={submit} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#00e599] py-3.5 text-sm font-extrabold text-[#04120d] disabled:opacity-60">{busy && <Loader2 size={16} className="animate-spin"/>} إرسال الطلب</button>
      </div>
    </div>
  </div>;
}
