import { HeroBanner } from '@/components/HeroBanner';

/** Backwards-compatible motion hero export. The minimal neon hero is now the canonical hero. */
export function MotionHero({ banners, onCta }: { banners?: unknown[]; onCta?: () => void }) {
  return <HeroBanner {...(banners !== undefined ? { banners } : {})} {...(onCta !== undefined ? { onCta } : {})} />;
}
