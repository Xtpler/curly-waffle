import { useEffect, useState } from 'react';
import { ClipboardCopy, Link2, Package, ReceiptText, Wallet } from 'lucide-react';
import { formatDate, formatIQD } from '@/lib/format';
import { useAuth } from '@/context/AuthContext';
import { listDeposits, listOrders } from '@/lib/store';
import { useWalletRealtime } from '@/hooks/useWallet';
import type { Deposit, Order, OrderStatus } from '@/types';

const STATUS_LABEL: Record<string, { text: string; className: string }> = {
  pending: { text: 'قيد المراجعة', className: 'bg-amber-400/10 text-amber-300' },
  approved: { text: 'تمت الموافقة', className: 'bg-emerald-400/10 text-emerald-300' },
  completed: { text: 'مكتمل', className: 'bg-emerald-400/10 text-emerald-300' },
  processing: { text: 'قيد التنفيذ', className: 'bg-sky-400/10 text-sky-300' },
  cancelled: { text: 'ملغى', className: 'bg-red-400/10 text-red-300' },
  rejected: { text: 'مرفوض', className: 'bg-red-400/10 text-red-300' },
};

export function StatusPill({ status }: { status: OrderStatus | string }) {
  const item = STATUS_LABEL[status] ?? STATUS_LABEL['pending']!;
  return <span className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-bold ${item.className}`}>{item.text}</span>;
}

export function OrdersPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [tab, setTab] = useState<'orders' | 'deposits'>('orders');

  const reload = () => {
    if (!user) return;
    listOrders(user.id).then(setOrders).catch(() => undefined);
    listDeposits(user.id).then(setDeposits).catch(() => undefined);
  };

  useEffect(reload, [user]);
  useWalletRealtime(reload);

  return (
    <Page title="طلباتي" subtitle="تابع حالة طلباتك وعمليات الإيداع">
      <div className="mb-6 flex gap-2 rounded-2xl bg-white/[.04] p-1">
        <button onClick={() => setTab('orders')} className={`rounded-xl px-4 py-2.5 text-xs font-bold ${tab === 'orders' ? 'bg-emerald-400 text-slate-950' : 'text-slate-400'}`}>الطلبات</button>
        <button onClick={() => setTab('deposits')} className={`rounded-xl px-4 py-2.5 text-xs font-bold ${tab === 'deposits' ? 'bg-emerald-400 text-slate-950' : 'text-slate-400'}`}>عمليات الإيداع</button>
      </div>

      {tab === 'orders' ? (
        <div className="space-y-3">
          {orders.length ? (
            orders.map((order) => (
              <div key={order.id} className="flex flex-col gap-4 rounded-2xl border border-white/[.08] bg-white/[.035] p-5 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-400/10 text-emerald-400"><Package size={22} /></div>
                  <div>
                    <h3 className="font-bold text-white">{order.product_name}</h3>
                    <p className="mt-1 text-xs text-slate-500">{formatDate(order.created_at)} · الكمية: {order.quantity}</p>
                    {order.target_link && (
                      <p className="mt-1 flex items-center gap-1 text-[11px] text-slate-400" dir="ltr">
                        <Link2 size={12} /> {order.target_link}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center justify-between gap-5 sm:justify-end">
                  <div className="text-right">
                    <p className="text-sm font-bold text-emerald-300">{formatIQD(order.price_iqd)}</p>
                    <div className="mt-1"><StatusPill status={order.status} /></div>
                  </div>
                  {order.code && (
                    <button onClick={() => navigator.clipboard.writeText(order.code)} className="flex items-center gap-2 rounded-xl border border-white/10 px-3 py-2 text-xs text-slate-300 hover:border-emerald-400/30 hover:text-emerald-300">
                      <ClipboardCopy size={14} /> نسخ الكود
                    </button>
                  )}
                </div>
              </div>
            ))
          ) : (
            <Empty text="لا توجد طلبات حتى الآن" hint="ابدأ بطلب أول خدمة من المتجر" />
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {deposits.length ? (
            deposits.map((d) => (
              <div key={d.id} className="flex flex-col gap-4 rounded-2xl border border-white/[.08] bg-white/[.035] p-5 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-400/10 text-emerald-400"><Wallet size={22} /></div>
                  <div>
                    <h3 className="font-bold text-white">{d.gateway_label}</h3>
                    <p className="mt-1 text-xs text-slate-500">{formatDate(d.created_at)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {d.receipt_url && <img src={d.receipt_url} alt="وصل التحويل" className="h-14 w-14 rounded-xl object-cover" />}
                  <div className="text-right">
                    <p className="text-sm font-bold text-emerald-300">{formatIQD(d.amount_iqd)}</p>
                    <div className="mt-1"><StatusPill status={d.status} /></div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <Empty text="لا توجد عمليات إيداع" hint="أضف رصيداً من صفحة حسابي" />
          )}
        </div>
      )}
    </Page>
  );
}

function Empty({ text, hint }: { text: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-white/10 py-20 text-center">
      <ReceiptText className="mx-auto text-slate-600" size={38} />
      <p className="mt-4 text-sm text-slate-400">{text}</p>
      <p className="mt-2 text-xs text-slate-600">{hint}</p>
    </div>
  );
}

function Page({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <main className="mx-auto min-h-[calc(100vh-150px)] max-w-[1440px] px-4 py-8 sm:px-5 sm:py-12 lg:px-10">
      <div className="mb-8">
        <p className="text-xs font-bold text-emerald-400">حسابك</p>
        <h1 className="mt-2 font-display text-3xl font-bold text-white">{title}</h1>
        <p className="mt-2 text-sm text-slate-400">{subtitle}</p>
      </div>
      {children}
    </main>
  );
}
export { Page };
