import { useEffect, useRef, useState } from 'react';
import { Check, Gift, Mail, Phone, Plus, ShieldCheck, Upload, UserRound, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { formatIQD } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { uploadAvatar } from '@/lib/data';
import { fileUrl, listDeposits, listWalletTransactions } from '@/lib/store';
import { redeemVoucher } from '@/lib/site';
import { useWalletRealtime } from '@/hooks/useWallet';
import { Page, StatusPill } from '@/pages/OrdersPage';
import type { Deposit } from '@/types';
import { DepositModal } from '@/components/DepositModal';
import { UnbanAppealModal } from '@/components/UnbanAppealModal';

type WalletTx = {
  id: string;
  amount: number;
  reason: string | null;
  created_at: string;
};

export function ProfilePage() {
  const { user, profile, refreshProfile } = useAuth();
  const [deposit, setDeposit] = useState(false);
  const [name, setName] = useState(profile?.full_name || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [saved, setSaved] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState('');
  const [voucherCode, setVoucherCode] = useState('');
  const [redeeming, setRedeeming] = useState(false);
  const [transactions, setTransactions] = useState<WalletTx[]>([]);
  const [pendingDeposits, setPendingDeposits] = useState<Deposit[]>([]);
  const [appealOpen, setAppealOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let active = true;
    if (profile?.avatar_url) {
      fileUrl(profile.avatar_url).then((url) => {
        if (active) setAvatarUrl(url);
      }).catch(() => undefined);
    } else {
      setAvatarUrl('');
    }
    return () => {
      active = false;
    };
  }, [profile?.avatar_url]);

  useEffect(() => {
    if (!user) return;
    listWalletTransactions(user.id).then((rows) => setTransactions(rows as unknown as WalletTx[]));
  }, [user, profile?.wallet_balance_iqd]);

  const reloadDeposits = () => {
    if (!user) return;
    listDeposits(user.id)
      .then((rows) => setPendingDeposits(rows.filter((d) => d.status === 'pending')))
      .catch(() => undefined);
  };

  useEffect(reloadDeposits, [user]);
  useWalletRealtime(reloadDeposits);

  const save = async () => {
    if (!profile) return;
    await supabase.from('profiles').update({ full_name: name, phone }).eq('id', profile.id);
    await refreshProfile();
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;
    setUploading(true);
    try {
      const stored = await uploadAvatar(profile.id, file);
      await supabase.from('profiles').update({ avatar_url: stored }).eq('id', profile.id);
      await refreshProfile();
      const url = await fileUrl(stored);
      setAvatarUrl(url);
    } catch {
      toast.error('تعذّر رفع الصورة');
    }
    setUploading(false);
  };

  const handleRedeem = async () => {
    if (!voucherCode.trim()) return;
    setRedeeming(true);
    const result = await redeemVoucher(voucherCode.trim());
    if (result.ok) {
      toast.success('تم شحن رصيدك بنجاح', { description: `تمت إضافة ${formatIQD(result.amount)} إلى محفظتك` });
      setVoucherCode('');
      await refreshProfile();
    } else {
      toast.error(result.error);
    }
    setRedeeming(false);
  };

  return (
    <div className="pt-20 sm:pt-24">
    <Page title="حسابي" subtitle="إدارة بياناتك الشخصية ومحفظتك">
      <div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]">
        {/* Left card */}
        <div className="rounded-3xl border border-emerald-400/20 bg-gradient-to-br from-emerald-400/15 to-transparent p-6">
          <div className="relative inline-block">
            {avatarUrl ? (
              <img src={avatarUrl} alt="avatar" className="h-20 w-20 rounded-2xl object-cover" />
            ) : (
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-emerald-400 text-slate-950">
                <UserRound size={36} />
              </div>
            )}
            <button
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="absolute -bottom-2 -left-2 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-400 text-slate-950 shadow-lg transition hover:bg-emerald-300 disabled:opacity-50"
            >
              <Upload size={15} />
            </button>
            <input ref={fileRef} type="file" accept="image/*" onChange={handleAvatar} className="hidden" />
          </div>
          <h2 className="mt-5 text-xl font-bold text-white">{profile?.full_name || 'مستخدم Ali Pro'}</h2>
          <p className="mt-2 text-sm text-slate-400">{profile?.email}</p>
          {uploading && <p className="mt-2 text-xs text-emerald-300">جاري رفع الصورة...</p>}
          <div className="mt-8 rounded-2xl border border-white/10 bg-slate-950/30 p-4">
            <div className="flex items-center gap-2 text-xs text-emerald-300">
              <Wallet size={15} /> رصيد المحفظة
            </div>
            <p className="mt-3 text-2xl font-bold text-white">{formatIQD(profile?.wallet_balance_iqd ?? 0)}</p>
            <p className="mt-2 text-[11px] text-slate-500">الرصيد متاح للشراء</p>
            <button
              onClick={() => setDeposit(true)}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 py-3 text-xs font-bold text-slate-950 hover:bg-emerald-300"
            >
              <Plus size={15} /> إضافة رصيد (إيداع)
            </button>
            {pendingDeposits.length > 0 && (
              <div className="mt-4 space-y-2 border-t border-white/10 pt-3">
                <p className="text-[11px] font-bold text-slate-400">طلبات إيداع نشطة</p>
                {pendingDeposits.map((d) => (
                  <div key={d.id} className="flex items-center justify-between rounded-xl bg-white/[.03] px-3 py-2">
                    <div>
                      <p className="text-[11px] font-bold text-slate-300">{d.gateway_label}</p>
                      <p className="text-[10px] text-emerald-300">{formatIQD(d.amount_iqd)}</p>
                    </div>
                    <StatusPill status={d.status} />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-4 rounded-2xl border border-white/10 bg-slate-950/30 p-4">
            <div className="flex items-center gap-2 text-xs text-emerald-300">
              <Gift size={15} /> كارت الشحن
            </div>
            <p className="mt-2 text-[11px] text-slate-500">أدخل كود الكارت لشحن رصيدك فوراً</p>
            <div className="mt-3 flex gap-2">
              <input
                value={voucherCode}
                onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                dir="ltr"
                placeholder="APM-XXXX-XXXX"
                className="h-11 flex-1 rounded-xl border border-white/10 bg-white/[.04] px-3 text-xs text-white outline-none focus:border-emerald-400/40"
              />
              <button
                onClick={handleRedeem}
                disabled={redeeming || !voucherCode.trim()}
                className="rounded-xl bg-emerald-400 px-4 text-xs font-bold text-slate-950 hover:bg-emerald-300 disabled:opacity-40"
              >
                شحن
              </button>
            </div>
          </div>

          {transactions.length > 0 && (
            <div className="mt-4 rounded-2xl border border-white/10 bg-slate-950/30 p-4">
              <p className="text-xs font-bold text-emerald-300">آخر حركات المحفظة</p>
              <ul className="mt-3 space-y-2">
                {transactions.slice(0, 6).map((tx) => (
                  <li key={tx.id} className="flex items-center justify-between text-xs text-slate-300">
                    <span className="truncate text-slate-400">{tx.reason || 'حركة محفظة'}</span>
                    <span className={tx.amount >= 0 ? 'font-bold text-emerald-300' : 'font-bold text-red-300'}>
                      {tx.amount >= 0 ? '+' : ''}{formatIQD(tx.amount)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {profile?.is_admin && (
            <div className="mt-4 flex items-center gap-2 rounded-xl bg-emerald-400/10 px-3 py-2 text-xs text-emerald-300">
              <ShieldCheck size={14} /> حساب أدمن
            </div>
          )}
          {profile?.is_banned && (
            <div className="mt-4 rounded-xl border border-red-400/20 bg-red-400/10 p-3 text-xs text-red-300"><p>حسابك محظور حالياً.</p><button onClick={() => setAppealOpen(true)} className="mt-3 rounded-lg bg-[#00e599] px-3 py-2 font-bold text-[#04120d]">تقديم طلب فك الباند</button></div>
          )}
          {profile?.is_restricted && (
            <div className="mt-4 rounded-xl bg-amber-400/10 px-3 py-2 text-xs text-amber-300">حسابك مقيد - بعض الميزات غير متاحة</div>
          )}
        </div>

        {/* Right form */}
        <div className="rounded-3xl border border-white/[.08] bg-white/[.035] p-6">
          <h2 className="text-lg font-bold text-white">المعلومات الشخصية</h2>
          <p className="mt-2 text-xs text-slate-500">تأكد من صحة بيانات التواصل الخاصة بك</p>
          <div className="mt-6 space-y-4">
            <Field icon={<UserRound size={17} />} label="الاسم الكامل" value={name} onChange={setName} />
            <div>
              <label className="mb-2 block text-xs text-slate-400">البريد الإلكتروني</label>
              <div className="flex h-12 items-center gap-3 rounded-xl border border-white/10 bg-white/[.03] px-4 text-sm text-slate-500">
                <Mail size={17} />{profile?.email}
              </div>
            </div>
            <Field icon={<Phone size={17} />} label="رقم الهاتف" value={phone} onChange={setPhone} />
            <button
              onClick={save}
              className="flex items-center gap-2 rounded-xl bg-emerald-400 px-5 py-3 text-sm font-bold text-slate-950 hover:bg-emerald-300"
            >
              {saved ? <Check size={16} /> : <ShieldCheck size={16} />}
              {saved ? 'تم الحفظ' : 'حفظ التغييرات'}
            </button>
          </div>
        </div>
      </div>
      <UnbanAppealModal open={appealOpen} onClose={() => setAppealOpen(false)} userId={user?.id ?? ''} />
      <DepositModal open={deposit} onClose={() => setDeposit(false)} onDone={() => { setDeposit(false); refreshProfile(); }} />
    </Page>
    </div>
  );
}

function Field({ icon, label, value, onChange }: { icon: React.ReactNode; label: string; value: string; onChange: (value: string) => void }) {
  return (
    <div>
      <label className="mb-2 block text-xs text-slate-400">{label}</label>
      <div className="relative">
        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500">{icon}</span>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-12 w-full rounded-xl border border-white/10 bg-white/[.03] pr-11 text-sm text-white outline-none focus:border-emerald-400/40"
        />
      </div>
    </div>
  );
}
