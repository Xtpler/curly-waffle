import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, ImagePlus, Loader2, Lock, Mail, MessageCircle, Phone, Plus, Send, Ticket, UserRound, X } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { getReplies, getTickets } from '@/lib/data';
import { formatDate } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { checkRateLimit, errorMessage, notifyAdmin, uploadAttachment } from '@/lib/store';
import { sanitizeText } from '@/lib/sanitize';
import type { SupportTicket, TicketReply } from '@/types';
import { Page } from '@/pages/OrdersPage';
import { Attachment } from '@/components/Attachment';
import { SupportWaiting } from '@/components/SupportWaiting';

export function SupportPage() {
  const { user, profile } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selected, setSelected] = useState<SupportTicket | null>(null);
  const [replies, setReplies] = useState<TicketReply[]>([]);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [reply, setReply] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [busy, setBusy] = useState(false);
  const [ticketFile, setTicketFile] = useState<File | null>(null);
  const [replyFile, setReplyFile] = useState<File | null>(null);
  const ticketFileRef = useRef<HTMLInputElement>(null);
  const replyFileRef = useRef<HTMLInputElement>(null);

  const load = async () => {
    if (user) setTickets(await getTickets(user.id).catch(() => []));
  };

  const reloadReplies = async (ticketId: string) => {
    setReplies(await getReplies(ticketId).catch(() => []));
  };

  useEffect(() => { load(); }, [user]);
  useEffect(() => {
    if (selected) reloadReplies(selected.id);
  }, [selected?.id]);

  const createTicket = async () => {
    if (!user) return;
    const cleanSubject = sanitizeText(subject, 160);
    const cleanMessage = sanitizeText(message, 2000);
    if (!cleanSubject || !cleanMessage) { toast.error('يرجى ملء جميع الحقول'); return; }
    if (!profile?.full_name || !profile?.phone) { toast.error('يرجى استكمال بياناتك الشخصية أولاً من صفحة حسابي'); return; }

    setBusy(true);
    try {
      const allowed = await checkRateLimit('ticket', 3, 300);
      if (!allowed) {
        toast.error('لقد أرسلت عدة تذاكر بسرعة. انتظر قليلاً ثم حاول مرة أخرى.');
        return;
      }

      // المرفق اختياري: عند فشل أو بطء رفع الصورة يُسجَّل الطلب بدون رابط
      let imageUrl = '';
      try {
        imageUrl = ticketFile ? await uploadAttachment(user.id, ticketFile) : '';
      } catch {
        imageUrl = '';
      }
      const payload = {
        user_id: user.id,
        subject: cleanSubject,
        message: cleanMessage,
        image_url: imageUrl,
        user_name: profile.full_name,
        user_email: profile.email,
        user_phone: profile.phone,
        user_avatar_url: profile.avatar_url || '',
      };
      const { error } = await supabase.from('support_tickets').insert(payload);
      if (error) { console.error('[ticket] insert failed:', error); toast.error(errorMessage(error)); return; }

      try {
        await notifyAdmin('تذكرة دعم جديدة', `${cleanSubject} · ${profile.full_name || profile.email}`);
      } catch {
        /* الإشعار الإداري ليس شرطاً لنجاح الإرسال */
      }
      toast.success('تم إرسال الطلب بنجاح 🎉');
      setSubject(''); setMessage(''); setTicketFile(null); setShowNew(false);
      await load();
    } catch (err) {
      console.error('[ticket] submission failed:', err);
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const sendReply = async () => {
    if (!selected || !user) return;
    const cleanReply = sanitizeText(reply, 2000);
    if (!cleanReply && !replyFile) return;

    setBusy(true);
    try {
      const allowed = await checkRateLimit('ticket_reply', 5, 300);
      if (!allowed) {
        toast.error('لقد أرسلت عدة ردود بسرعة. انتظر قليلاً ثم حاول مرة أخرى.');
        return;
      }

      // المرفق اختياري: عند فشل أو بطء رفع الصورة يُسجَّل الرد بدون رابط
      let imageUrl = '';
      if (replyFile) {
        try {
          imageUrl = await uploadAttachment(user.id, replyFile);
        } catch {
          imageUrl = '';
        }
      }
      const payload = {
        ticket_id: selected.id,
        user_id: user.id,
        message: cleanReply,
        image_url: imageUrl,
        is_admin_reply: false,
      };
      const { error } = await supabase.from('ticket_replies').insert(payload);
      if (error) { console.error('[reply] insert failed:', error); toast.error(errorMessage(error)); return; }

      await notifyAdmin('رد جديد على تذكرة', `${selected.subject} · ${profile?.full_name || profile?.email || 'مستخدم'}`);
      toast.success('تم إرسال الرد');
      setReply(''); setReplyFile(null);
      await reloadReplies(selected.id);
    } catch (err) {
      console.error('[reply] submission failed:', err);
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const restricted = profile?.is_restricted;

  return (
    <div className="pt-20 sm:pt-24">
    <Page title="الدعم الفني" subtitle="نحن هنا لمساعدتك في كل خطوة">
      <div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]">
        {/* Tickets list */}
        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-bold text-white">تذاكري</h2>
            <button
              onClick={() => setShowNew(true)}
              disabled={restricted}
              className="flex items-center gap-2 rounded-xl bg-emerald-400 px-3 py-2 text-xs font-bold text-slate-950 disabled:opacity-40"
            >
              <Plus size={15} /> تذكرة جديدة
            </button>
          </div>
          {restricted && (
            <div className="mb-3 rounded-xl bg-amber-400/10 px-3 py-2 text-xs text-amber-300">
              حسابك مقيد - لا يمكن إنشاء تذاكر جديدة
            </div>
          )}
          <div className="space-y-3">
            {tickets.map((ticket) => (
              <button
                key={ticket.id}
                onClick={() => setSelected(ticket)}
                className={`w-full rounded-2xl border p-4 text-right transition ${selected?.id === ticket.id ? 'border-emerald-400/40 bg-emerald-400/[.07]' : 'border-white/[.08] bg-white/[.035] hover:border-white/20'}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white">{ticket.subject}</h3>
                    <p className="mt-2 line-clamp-1 text-xs text-slate-500">{ticket.message}</p>
                  </div>
                  <span className={`rounded-full px-2 py-1 text-[10px] ${ticket.status === 'open' ? 'bg-emerald-400/10 text-emerald-300' : 'bg-white/10 text-slate-400'}`}>
                    {ticket.status === 'open' ? 'مفتوحة' : 'مغلقة'}
                  </span>
                </div>
                <p className="mt-3 text-[10px] text-slate-600">{formatDate(ticket.created_at)}</p>
              </button>
            ))}
            {!tickets.length && (
              <div className="rounded-2xl border border-dashed border-white/10 py-16 text-center">
                <Ticket className="mx-auto text-slate-600" size={36} />
                <p className="mt-3 text-sm text-slate-400">لا توجد تذاكر بعد</p>
              </div>
            )}
          </div>
        </section>

        {/* Conversation */}
        <section className="min-h-[420px] rounded-3xl border border-white/[.08] bg-white/[.035] p-5">
          {selected ? (
            <>
              {selected.status === 'open' && !replies.some((r) => r.is_admin_reply) && (
                <div className="mb-4">
                  <SupportWaiting compact />
                </div>
              )}
              <div className="flex items-start justify-between border-b border-white/10 pb-4">
                <div>
                  <p className="text-xs text-emerald-400">تفاصيل التذكرة</p>
                  <h2 className="mt-1 text-lg font-bold text-white">{selected.subject}</h2>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`flex items-center gap-1 rounded-full px-2 py-1 text-[10px] ${selected.status === 'open' ? 'bg-emerald-400/10 text-emerald-300' : 'bg-white/10 text-slate-400'}`}>
                    {selected.status === 'open' ? <CheckCircle2 size={12} /> : <Lock size={12} />}
                    {selected.status === 'open' ? 'مفتوحة' : 'مغلقة'}
                  </span>
                  <MessageCircle className="text-emerald-400" />
                </div>
              </div>

              {/* User info captured on ticket */}
              {(selected.user_name || selected.user_email || selected.user_phone) && (
                <div className="mt-4 flex flex-wrap items-center gap-4 rounded-2xl bg-white/[.04] p-3">
                  {selected.user_avatar_url && (
                    <img src={selected.user_avatar_url} alt="" className="h-10 w-10 rounded-full object-cover" />
                  )}
                  {selected.user_name && (
                    <span className="flex items-center gap-1.5 text-xs text-slate-300"><UserRound size={13} /> {selected.user_name}</span>
                  )}
                  {selected.user_email && (
                    <span className="flex items-center gap-1.5 text-xs text-slate-400"><Mail size={13} /> {selected.user_email}</span>
                  )}
                  {selected.user_phone && (
                    <span className="flex items-center gap-1.5 text-xs text-slate-400"><Phone size={13} /> {selected.user_phone}</span>
                  )}
                </div>
              )}

              <div className="mt-4 rounded-2xl bg-white/[.04] p-4 text-sm leading-7 text-slate-300">
                {selected.message}
                <Attachment stored={selected.image_url} label="مرفق التذكرة" />
              </div>

              <div className="mt-4 space-y-3">
                {replies.map((item) => (
                  <div
                    key={item.id}
                    className={`rounded-2xl p-4 text-sm leading-6 ${item.is_admin_reply ? 'mr-8 border border-emerald-400/20 bg-emerald-400/10 text-emerald-100' : 'ml-8 bg-white/[.05] text-slate-300'}`}
                  >
                    {item.is_admin_reply && (
                      <p className="mb-1 text-[10px] font-bold text-emerald-300">فريق الدعم</p>
                    )}
                    {item.message}
                    <Attachment stored={item.image_url} label="مرفق الرد" />
                    <p className="mt-2 text-[10px] text-slate-500">{formatDate(item.created_at)}</p>
                  </div>
                ))}
              </div>

              {selected.status === 'open' ? (
                <div className="mt-5">
                  <div className="flex gap-2">
                    <input
                      value={reply}
                      onChange={(e) => setReply(e.target.value)}
                      placeholder="اكتب ردك..."
                      className="h-11 flex-1 rounded-xl border border-white/10 bg-white/[.04] px-4 text-sm text-white outline-none focus:border-emerald-400/40"
                    />
                    <input ref={replyFileRef} type="file" accept="image/*" hidden onChange={(e) => setReplyFile(e.target.files?.[0] ?? null)} />
                    <button onClick={() => replyFileRef.current?.click()} title="إرفاق صورة" className="rounded-xl border border-white/10 bg-white/[.06] px-3 text-slate-300 hover:bg-white/10">
                      <ImagePlus size={17} />
                    </button>
                    <button disabled={busy} onClick={sendReply} className="rounded-xl bg-emerald-400 px-4 text-slate-950 disabled:opacity-50">
                      {busy ? <Loader2 className="animate-spin" size={17} /> : <Send size={17} />}
                    </button>
                  </div>
                  {replyFile && (
                    <p className="mt-2 flex items-center gap-2 text-[11px] text-emerald-300">
                      {replyFile.name}
                      <button onClick={() => setReplyFile(null)} className="text-slate-400"><X size={12} /></button>
                    </p>
                  )}
                </div>
              ) : (
                <div className="mt-5 flex items-center gap-2 rounded-xl bg-white/[.05] px-4 py-3 text-xs text-slate-400">
                  <Lock size={14} /> هذه التذكرة مغلقة
                </div>
              )}
            </>
          ) : (
            <div className="flex h-full min-h-[380px] flex-col items-center justify-center text-center">
              <SupportWaiting />
            </div>
          )}
        </section>
      </div>

      {/* New ticket modal */}
      {showNew && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-slate-900 p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">تذكرة دعم جديدة</h2>
              <button onClick={() => setShowNew(false)} className="text-slate-400"><X /></button>
            </div>

            {/* Mandatory user info preview */}
            <div className="mt-5 flex flex-wrap items-center gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/[.05] p-3">
              {profile?.avatar_url && <img src={profile.avatar_url} alt="" className="h-9 w-9 rounded-full object-cover" />}
              <span className="flex items-center gap-1.5 text-xs text-emerald-200"><UserRound size={13} /> {profile?.full_name || 'غير محدد'}</span>
              <span className="flex items-center gap-1.5 text-xs text-emerald-200"><Mail size={13} /> {profile?.email}</span>
              <span className="flex items-center gap-1.5 text-xs text-emerald-200"><Phone size={13} /> {profile?.phone || 'غير محدد'}</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-500">سيتم إرفاق بياناتك تلقائياً مع التذكرة</p>

            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="عنوان المشكلة"
              className="mt-4 h-12 w-full rounded-xl border border-white/10 bg-white/[.04] px-4 text-sm text-white outline-none"
            />
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="اشرح لنا كيف يمكننا مساعدتك"
              className="mt-3 min-h-32 w-full resize-none rounded-xl border border-white/10 bg-white/[.04] p-4 text-sm text-white outline-none"
            />
            <input ref={ticketFileRef} type="file" accept="image/*" hidden onChange={(e) => setTicketFile(e.target.files?.[0] ?? null)} />
            <button
              onClick={() => ticketFileRef.current?.click()}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[.03] py-3 text-xs font-bold text-slate-300 hover:border-emerald-400/40"
            >
              <ImagePlus size={16} /> {ticketFile ? ticketFile.name : 'إرفاق صورة أو لقطة شاشة (اختياري)'}
            </button>
            {ticketFile && (
              <button onClick={() => setTicketFile(null)} className="mt-2 text-[11px] text-red-300">إزالة المرفق</button>
            )}
            <button
              onClick={createTicket}
              disabled={busy}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 py-3 font-bold text-slate-950 disabled:opacity-50"
            >
              {busy ? <Loader2 className="animate-spin" size={17} /> : <Send size={17} />} {busy ? 'جارٍ الإرسال...' : 'إرسال التذكرة'}
            </button>
          </div>
        </div>
      )}
    </Page>
    </div>
  );
}
