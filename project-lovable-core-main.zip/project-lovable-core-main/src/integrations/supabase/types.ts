export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      action_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      announcements: {
        Row: {
          active: boolean
          created_at: string
          id: string
          message: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          message?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          message?: string
        }
        Relationships: []
      }
      banners: {
        Row: {
          active: boolean
          created_at: string
          cta_text: string
          id: string
          image_url: string
          sort_order: number
          subtitle: string
          title: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          cta_text?: string
          id?: string
          image_url?: string
          sort_order?: number
          subtitle?: string
          title?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          cta_text?: string
          id?: string
          image_url?: string
          sort_order?: number
          subtitle?: string
          title?: string
        }
        Relationships: []
      }
      deposits: {
        Row: {
          admin_note: string
          amount_iqd: number
          created_at: string
          gateway: string
          gateway_label: string
          id: string
          receipt_url: string
          reviewed_at: string | null
          sender_note: string
          status: string
          user_email: string
          user_id: string
          user_name: string
          user_phone: string
        }
        Insert: {
          admin_note?: string
          amount_iqd?: number
          created_at?: string
          gateway?: string
          gateway_label?: string
          id?: string
          receipt_url?: string
          reviewed_at?: string | null
          sender_note?: string
          status?: string
          user_email?: string
          user_id: string
          user_name?: string
          user_phone?: string
        }
        Update: {
          admin_note?: string
          amount_iqd?: number
          created_at?: string
          gateway?: string
          gateway_label?: string
          id?: string
          receipt_url?: string
          reviewed_at?: string | null
          sender_note?: string
          status?: string
          user_email?: string
          user_id?: string
          user_name?: string
          user_phone?: string
        }
        Relationships: []
      }
      market_account_secrets: {
        Row: {
          account_id: string
          credentials: string
        }
        Insert: {
          account_id: string
          credentials?: string
        }
        Update: {
          account_id?: string
          credentials?: string
        }
        Relationships: [
          {
            foreignKeyName: "market_account_secrets_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: true
            referencedRelation: "market_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      market_accounts: {
        Row: {
          created_at: string
          description: string
          followers: number
          id: string
          image_url: string
          platform: string
          price_iqd: number
          sold: boolean
          sold_to: string | null
          title: string
        }
        Insert: {
          created_at?: string
          description?: string
          followers?: number
          id?: string
          image_url?: string
          platform?: string
          price_iqd?: number
          sold?: boolean
          sold_to?: string | null
          title?: string
        }
        Update: {
          created_at?: string
          description?: string
          followers?: number
          id?: string
          image_url?: string
          platform?: string
          price_iqd?: number
          sold?: boolean
          sold_to?: string | null
          title?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          audience: string
          created_at: string
          id: string
          kind: string
          message: string
          read: boolean
          title: string
          user_id: string | null
        }
        Insert: {
          audience?: string
          created_at?: string
          id?: string
          kind?: string
          message?: string
          read?: boolean
          title?: string
          user_id?: string | null
        }
        Update: {
          audience?: string
          created_at?: string
          id?: string
          kind?: string
          message?: string
          read?: boolean
          title?: string
          user_id?: string | null
        }
        Relationships: []
      }
      orders: {
        Row: {
          admin_note: string
          buyer_email: string
          buyer_name: string
          buyer_phone: string
          category: string
          code: string
          created_at: string
          credentials: string
          id: string
          kind: string
          payment_method: string
          price_iqd: number
          product_id: string | null
          product_name: string
          quantity: number
          status: string
          target_link: string
          unit_price_iqd: number
          user_id: string
        }
        Insert: {
          admin_note?: string
          buyer_email?: string
          buyer_name?: string
          buyer_phone?: string
          category?: string
          code?: string
          created_at?: string
          credentials?: string
          id?: string
          kind?: string
          payment_method?: string
          price_iqd?: number
          product_id?: string | null
          product_name?: string
          quantity?: number
          status?: string
          target_link?: string
          unit_price_iqd?: number
          user_id: string
        }
        Update: {
          admin_note?: string
          buyer_email?: string
          buyer_name?: string
          buyer_phone?: string
          category?: string
          code?: string
          created_at?: string
          credentials?: string
          id?: string
          kind?: string
          payment_method?: string
          price_iqd?: number
          product_id?: string | null
          product_name?: string
          quantity?: number
          status?: string
          target_link?: string
          unit_price_iqd?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          available: boolean
          category: string
          created_at: string
          description: string
          icon: string
          id: string
          image_url: string
          name: string
          name_ar: string
          price_iqd: number
          sort_order: number
        }
        Insert: {
          available?: boolean
          category?: string
          created_at?: string
          description?: string
          icon?: string
          id?: string
          image_url?: string
          name?: string
          name_ar?: string
          price_iqd?: number
          sort_order?: number
        }
        Update: {
          available?: boolean
          category?: string
          created_at?: string
          description?: string
          icon?: string
          id?: string
          image_url?: string
          name?: string
          name_ar?: string
          price_iqd?: number
          sort_order?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string
          created_at: string
          email: string
          full_name: string
          id: string
          is_banned: boolean
          is_restricted: boolean
          phone: string
          updated_at: string
          wallet_balance_iqd: number
        }
        Insert: {
          avatar_url?: string
          created_at?: string
          email?: string
          full_name?: string
          id: string
          is_banned?: boolean
          is_restricted?: boolean
          phone?: string
          updated_at?: string
          wallet_balance_iqd?: number
        }
        Update: {
          avatar_url?: string
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          is_banned?: boolean
          is_restricted?: boolean
          phone?: string
          updated_at?: string
          wallet_balance_iqd?: number
        }
        Relationships: []
      }
      push_devices: {
        Row: {
          created_at: string
          id: string
          player_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          player_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          player_id?: string
          user_id?: string
        }
        Relationships: []
      }
      support_tickets: {
        Row: {
          created_at: string
          id: string
          image_url: string
          message: string
          status: string
          subject: string
          user_avatar_url: string
          user_email: string
          user_id: string
          user_name: string
          user_phone: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_url?: string
          message?: string
          status?: string
          subject?: string
          user_avatar_url?: string
          user_email?: string
          user_id: string
          user_name?: string
          user_phone?: string
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string
          message?: string
          status?: string
          subject?: string
          user_avatar_url?: string
          user_email?: string
          user_id?: string
          user_name?: string
          user_phone?: string
        }
        Relationships: []
      }
      ticket_replies: {
        Row: {
          created_at: string
          id: string
          image_url: string
          is_admin_reply: boolean
          message: string
          ticket_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_url?: string
          is_admin_reply?: boolean
          message?: string
          ticket_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string
          is_admin_reply?: boolean
          message?: string
          ticket_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ticket_replies_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vouchers: {
        Row: {
          active: boolean
          amount_iqd: number
          code: string
          created_at: string
          id: string
          used_at: string | null
          used_by: string | null
        }
        Insert: {
          active?: boolean
          amount_iqd?: number
          code: string
          created_at?: string
          id?: string
          used_at?: string | null
          used_by?: string | null
        }
        Update: {
          active?: boolean
          amount_iqd?: number
          code?: string
          created_at?: string
          id?: string
          used_at?: string | null
          used_by?: string | null
        }
        Relationships: []
      }
      wallet_transactions: {
        Row: {
          amount_iqd: number
          balance_after: number
          created_at: string
          id: string
          reason: string
          user_id: string
        }
        Insert: {
          amount_iqd: number
          balance_after?: number
          created_at?: string
          id?: string
          reason?: string
          user_id: string
        }
        Update: {
          amount_iqd?: number
          balance_after?: number
          created_at?: string
          id?: string
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_adjust_wallet: {
        Args: { _amount: number; _reason?: string; _user_id: string }
        Returns: number
      }
      check_rate_limit: {
        Args: { _action: string; _max: number; _window_seconds: number }
        Returns: boolean
      }
      credit_wallet: {
        Args: { _amount: number; _reason: string; _user_id: string }
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      ensure_master_admin: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      is_master_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      purchase_with_wallet: {
        Args: {
          _buyer_email: string
          _buyer_name: string
          _buyer_phone: string
          _category: string
          _kind: string
          _market_account_id?: string
          _product_id: string
          _product_name: string
          _quantity: number
          _target_link: string
          _unit_price: number
        }
        Returns: {
          admin_note: string
          buyer_email: string
          buyer_name: string
          buyer_phone: string
          category: string
          code: string
          created_at: string
          credentials: string
          id: string
          kind: string
          payment_method: string
          price_iqd: number
          product_id: string | null
          product_name: string
          quantity: number
          status: string
          target_link: string
          unit_price_iqd: number
          user_id: string
        }
        SetofOptions: {
          from: "*"
          to: "orders"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      redeem_voucher: { Args: { _code: string }; Returns: number }
      review_deposit: {
        Args: { _approve: boolean; _deposit_id: string; _note?: string }
        Returns: number
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
